const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');  // <-- needed for static file serving
const jobRoutes = require('./routes/jobRoutes');
const companyRoutes = require('./routes/companyRoutes');
const salarayRoutes = require('./routes/salaryRoutes');
const userRoutes = require('./routes/userRoute');
const cors = require('cors');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json()); // Middleware to parse JSON request body

// Backend routes
app.use(jobRoutes);
app.use(companyRoutes);
app.use(salarayRoutes);
app.use(userRoutes);

// Serve React frontend
app.use(express.static(path.join(__dirname, 'build')));

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URL)
    .then(() => console.log('Connected to MongoDB'))
    .catch(error => console.error('Error connecting to MongoDB:', error));

// Use EB-assigned port or fallback to 5000
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
